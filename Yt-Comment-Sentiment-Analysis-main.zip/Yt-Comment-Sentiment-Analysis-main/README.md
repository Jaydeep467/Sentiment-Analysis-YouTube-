# Yt-Comment-Sentiment-Analysis
This is a software where the user or a content creator can paste the URL of the desired YouTube
video and the software displays the sentiment of the video and generates a WordCloud visualization.
NLTK(Natural Language Toolkit) , scikit-learn and pandas were used for analyzing; WordCloud for
visualization and Tkinter for GUI.
